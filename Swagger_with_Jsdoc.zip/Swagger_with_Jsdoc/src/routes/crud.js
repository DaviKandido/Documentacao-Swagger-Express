const express = require("express");
const crudController = require("../controllers/crud.controller");

const router = express.Router();



 /* 
@swagger
components:
  schemas:
    Post:
      type: object
      required:
        - title
        - content
      properties:
        id:
          type: number
        title:
          type: string
        content:
          type: string
  securitySchemes:
    bearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT
*/

router.get("/", crudController.index);

router.get("/:id", crudController.show);

router.post("/", crudController.save);

router.put("/:id", crudController.update);

router.delete("/:id", crudController.destroy);


module.exports = router